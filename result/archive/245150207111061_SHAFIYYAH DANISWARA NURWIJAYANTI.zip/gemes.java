package tugaslaprak2.seminarjava1;
public class gemes {
    public static void main(String[] args) {
        Scanner scanner= new Scanner (System.in);
        
    }
    
}
