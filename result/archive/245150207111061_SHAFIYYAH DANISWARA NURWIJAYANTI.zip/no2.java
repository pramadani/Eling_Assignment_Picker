package tugaslaprak2;

public class no2 {
    public static void main(String[] args){
        String s = "filkom";
        int val = (s=="filkom")?"Brawijaya": "null"; 
        System.out.println(s+" "+val);
       
    }
}
