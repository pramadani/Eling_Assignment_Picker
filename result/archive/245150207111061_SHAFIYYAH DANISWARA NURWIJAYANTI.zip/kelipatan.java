package tugaslaprak2.seminarjava1;
import java.util.Scanner;
public class kelipatan {
    public static void main(String[] args) {
        Scanner scanner= new scanner (System.in);
        int bil = 0;
        while (bil <=1000000) {
            System.out.println("kelipatan 17");
            
        }
    }
}
