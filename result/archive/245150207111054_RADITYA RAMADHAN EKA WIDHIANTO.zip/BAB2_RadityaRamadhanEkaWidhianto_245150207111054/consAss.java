package PRAKTIKUM2;
import java.util.Scanner;

public class consAss {
    public static void main(String[] args) {
        String s = "filkom";
        String val = (s=="filkom")?"Brawijaya": "null";
        
        //Scanner in = new Scanner(System.in);
        //String namaIn = in.nextLine();
        //String passIn = in.nextLine();

        //String nama = "Raditya";
        //String pass = "11223344";

        //String namaOut = (namaIn.equals(nama)) ? namaIn : "Input Nama Salah";
        //String nimOut = (passIn.equals(pass)) ?  passIn : "Input NIM Salah";
        System.out.println(s+" "+val);
        //String hasil = (namaIn.equals(nama) && passIn.equals(pass)) ? "Infomasi Data Mahasiswa" : "Data Tidak Ditemukan";
        //System.out.println(hasil);

    }
}
