import java.util.Scanner;
public class contAss {
    public static void main(String[]args){
        String s = "filkom";
        String val = (s == "filkom") ? "Brawijaya": "null";
        System.out.println(s+" "+val);
    
    Scanner input = new Scanner(System.in);
    String nama = input.nextLine();
    String nim = input.nextLine();
    String nama1 = "Fevoura";
    String nim1 = "24515020";
    String cek1 = (nama.equals (nama1)) ? "" : "Input nama tidak sesuai";
    String cek2 = (nim.equals (nim1)) ? "" : "Input nim tidak sesuai";

    String hasil = (nama.equals (nama1) && nim.equals (nim1)) ? "data sesuai" : cek1 + cek2;
System.out.println(hasil);

    }
}
