import java.util.Scanner;
public class No4 {
    public static void main (String[] args){
Scanner input = new Scanner(System.in);
String nama = input.nextLine();
String pass = input.nextLine();

String nama1, pass1;
System.out.println("Masukkan nama anda : " );
nama1 = input.nextLine();
System.out.println("Masukkan password anda : ");
pass1 = input.nextLine();

String hasil = (nama1.equals (nama) && pass1.equals (pass)) ? nama1 + " " + pass1 : "data tak ditemukan";
System.out.println(hasil);
    }
    
}
