import java.util.Scanner;
import java.util.Scanner;
    public class Menu {
        public static void main (String[] args) {
            Scanner in = new Scanner(System.in);
        
            int masuk;
            System.out.println("Menu");
            System.out.println("1. menghitung luas dan keliling persegi panjang ");
            System.out.println("2. menghitung luas dan keliling lingkaran ");
            System.out.println("3. menghitung luas dan keliling segitiga ");
            System.out.println("Pilihan anda: ");
            
            masuk = in.nextInt();

            if (masuk == 1) {
                System.out.println("Masukkan panjang:  ");
                double panjang = in.nextDouble();
                System.out.println("Masukkan lebar:  ");
                double lebar = in.nextDouble();
               
                double luas = panjang*lebar;
                double keliling = 2 * (panjang + lebar);

                System.out.println("Luas persegi panjang : " + luas + "cm2");
                System.out.println("Keliling persegi panjang : " + keliling + "cm2");

            } else if (masuk == 2) {
                System.out.println("Masukkan jari-jari (r) : ");
                double r  = in.nextDouble();

                double luas = Math.PI * r * r;
                double keliling = 2 * Math.PI * r;

                System.out.printf("Luas lingkaran  : %.2f cm2\n", luas);
                System.out.printf("Keliling lingkaran  : %.2f cm2\n", keliling);

            } else if (masuk == 3){
                System.out.println("Masukkan a:  ");
                double a = in.nextDouble();
                System.out.println("Masukkan b:  ");
                double b = in.nextDouble();
                System.out.println("Masukkan r (alas):  ");
                double r = in.nextDouble();
                
                double keliling = a + b + r;
                double s = keliling / 2;
                double luas = Math.sqrt (s *(s-a) * (s - b) * (s-r));

                System.out.printf("Keliling segitiga  : " + keliling + " cm2");
                System.out.printf("Keliling luas  : " + luas + " cm2");


            } else {
                System.out.println("Data tak ditemukan, program dihentikan ... ");
            }


        }
    }
