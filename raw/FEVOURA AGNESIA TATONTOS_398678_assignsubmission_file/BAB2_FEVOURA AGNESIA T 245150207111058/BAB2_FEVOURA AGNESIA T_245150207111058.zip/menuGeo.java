
import java.util.Scanner;
    public class menuGeo {
        public static void main (String[] args) {
            Scanner in = new Scanner(System.in);
        
            int masuk;
            System.out.println("Menu");
            System.out.println("1. menghitung luas dan keliling persegi panjang ");
            System.out.println("2. menghitung luas dan keliling lingkaran ");
            System.out.println("3. menghitung luas dan keliling segitiga ");
           
            System.out.print("Pilihan anda: " );
            masuk = in.nextInt();
            
           
            switch (masuk) {
                case 1:
                System.out.println("Masukkan panjang:  ");
                double panjang = in.nextDouble();
                System.out.println("Masukkan lebar:  ");
                double lebar = in.nextDouble();
               
                double luas = panjang*lebar;
                double keliling = 2 * (panjang + lebar);

                System.out.println("Luas persegi panjang : " + luas + "cm2");
                System.out.println("Keliling persegi panjang : " + keliling + "cm2");
break;
case 2:
                System.out.println("Masukkan jari-jari (r) : ");
                double r  = in.nextDouble();

                double luas1 = Math.PI * r * r;
                double keliling1 = 2 * Math.PI * r;

                System.out.printf("Luas lingkaran  : %.2f cm2\n", luas1);
                System.out.printf("Keliling lingkaran  : %.2f cm2\n", keliling1);
                break;

             case 3: 
                System.out.printf("%-12s" ,"Masukkan a:  ");
                double a = in.nextDouble();
                System.out.printf("%-12s" ,"Masukkan b:  ");
                double b = in.nextDouble();
                System.out.printf("%-12s" ,"Masukkan r:  ");
                double r1 = in.nextDouble();
                
                double keliling2 = a + b + r1;
                double s = keliling2 / 2;
                double luas2 = Math.sqrt (s *(s-a) * (s - b) * (s-r1));

                System.out.printf("%-20s : %.2f cm2\n","Luas segitiga  ", luas2);
                System.out.printf("%-20s : %.2f cm","Keliling segitiga  ", keliling2);

            break;
             default:
                System.out.println("Data tak ditemukan, program dihentikan ... ");
                break;
            }

            in.close();

        }
    }
