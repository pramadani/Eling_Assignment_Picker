import java.util.Scanner;
public class egawai {
    public static void main(String[] args){
Scanner in = new Scanner(System.in);

System.out.print("Jam kerja : ");
int jam = in.nextInt();
 
int pay, lembur = 0, denda = 0;
final int NORMALPAY = 5000;
final int LEMBURPAY = 6000;
final int MAX = 60;
final int  MIN = 50;

if (jam > MAX){
    lembur = (jam - MAX) * LEMBURPAY;
    pay = (MAX * NORMALPAY);
} else if (jam >= MIN) {
    pay = (jam*NORMALPAY);
} else{
    denda = (MIN - jam) * 1000;
    pay = jam * NORMALPAY;
}
int total = pay + lembur - denda;
System.out.printf("%-10s = %d\n" ,"Upah", pay);
System.out.printf("%-10s = Rp %d\n" ,"Lembur", lembur);
System.out.printf("%-10s = Rp %d\n" ,"Denda", denda);
System.out.println("--------------------- ");
System.out.printf("%-10s = Rp %d" ,"Total", total);

in.close();
    }
}
