/**
 * 
 */
/**
 * 
 */
module praktikum2 {
}