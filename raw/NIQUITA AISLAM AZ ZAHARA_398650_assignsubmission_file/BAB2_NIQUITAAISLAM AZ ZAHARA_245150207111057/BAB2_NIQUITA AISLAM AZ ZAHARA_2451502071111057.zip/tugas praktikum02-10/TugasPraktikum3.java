/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tugaspraktikum3;

import java.util.Scanner;

public class TugasPraktikum3 {

    public static void main(String[] args) {
    
        Scanner input = new Scanner (System.in);
        
       
        int jam = input.nextInt();
        System.out.println("Jam Kerja : " + jam);
        
        int upahJam  = 5000;
        int lemburJam = 6000;
        int dendaJam = 1000;
        int MaksimalJamKerja = 60;
        int MinimalJamKerja = 50;
        
        
        if (jam > MaksimalJamKerja) {
            int jamLembur = (jam - MaksimalJamKerja);
            int totalUpah = (MaksimalJamKerja * upahJam) + (jamLembur * lemburJam);
            int denda = 0;
            System.out.printf("%-8s= Rp %, d%n", "Upah", MaksimalJamKerja * upahJam);
            System.out.printf("%-8s= Rp %, d%n", "Lembur", jamLembur * lemburJam);
            System.out.printf("%-8s= Rp %, d%n", "Denda", denda);
            System.out.println("---------------------");
            System.out.printf("%-8s= Rp %, d%n", "Total", totalUpah);
            
        } else if (jam < MinimalJamKerja)  {
            int jamKurang = (MinimalJamKerja - jam);
            int totalUpah = (jam * upahJam) - (jamKurang * dendaJam);
            int lembur = 0;
            System.out.printf("%-8s= Rp %, d%n", "Upah", jam * upahJam);
            System.out.printf("%-8s= Rp %, d%n", "Lembur", lembur);
            System.out.printf("%-8s= Rp %, d%n", "Denda", jamKurang * dendaJam);
            System.out.println("---------------------");
            System.out.printf("%-8s= Rp %, d%n", "Total", totalUpah);
        } else {
            int totalUpah = jam * upahJam;
            int lembur = 0;
            int denda = 0;
            System.out.println("---------------------");
            System.out.printf("%-8s= Rp %, d%n", "Upah", totalUpah);
            System.out.printf("%-8s= Rp %, d%n", "Lembur", lembur);
            System.out.printf("%-8s= Rp %, d%n", "Denda", denda);
            System.out.printf("%-8s= Rp %, d%n", "Total", totalUpah); 
            
        }
     }  
    }

 
      
      
      
      


      


      

      
     