/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tugaspraktikum2;

import java.util.Scanner;


public class TugasPraktikum1 {

    
    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);
        
        System.out.println("Menu:");
        System.out.println("1. menghitung luas dan keliling persegi panjang");
        System.out.println("2. menghitung luas dan keliling lingkaran");
        System.out.println("3. menghitung luas dan keliling segitiga");

      
        
        System.out.print("Pilihan anda: ");
        int pilihan = input.nextInt();
        
        
        System.out.print("Masukkan a: " );
        int a = input.nextInt();
        
        System.out.print("Masukkan b: " );
        int b = input.nextInt();
        
        System.out.print("Masukkan r: " );
        int r = input.nextInt();
        
        
        switch (pilihan) {
            case 1 -> {
              int KelilingPersegiPanjang = (2 * ( a + b));
              System.out.printf("%-20s : %d%n", "Keliling persegi panjang", KelilingPersegiPanjang);
              
              int LuasPersegiPanjang = (a * b);
              System.out.printf("%-20s : %d%n", "luas persegi panjang", LuasPersegiPanjang);        
            }
            case 2 -> {
                 double KelilingLingkaran = (3.14 * 2 * r);
             System.out.printf("%-20s : %.2f%n", "Keliling persegi panjang", KelilingLingkaran); 
              
              double LuasLingkaran = (3.14 * r * r);
              System.out.printf("%-20s : %.2f%n", "luas persegi panjang", LuasLingkaran);
            }
            case 3 -> {
              int KelilingsSegitiga = ( a + b + r);  
              System.out.printf("%-20s : %d cm%n", "Keliling segitiga", KelilingsSegitiga);
              
              int LuasSegitiga = (( a * b)/2);
              System.out.printf("%-20s : %d cm2%n", "luas segitiga", LuasSegitiga);
              
            }default ->{
              
              System.out.println("data tak ditemukan, , program dihentikan ...");
                
            }
        }
        
    }
}
  
        
        
        
        
        
       
      
       
        
        
    
    

