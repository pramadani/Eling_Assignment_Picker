/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tugaspraktikum1;

import java.util.Scanner;


public class TugasPraktikum2 {

    public static void main(String[] args) {
      Scanner input = new Scanner (System.in);
      
      System.out.print("masukkan berat badan : ");
      double BeratBadan = input.nextDouble();
      
      System.out.print("masukkan tinggi badan : ");
      double TinggiBadan = input.nextDouble();
      
      double TinggiBadanMeter = TinggiBadan / 100.0;
      System.out.println("Tinggi badan dalam meter " + TinggiBadanMeter);
      
      double IMT  = BeratBadan / (TinggiBadanMeter * TinggiBadanMeter);
      System.out.println("jadi IMT : " + IMT);
      
      System.out.printf("%-20s : %.2f kg%n", "Berat badan (kg)", BeratBadan);
      System.out.printf("%-20s : %.2f m%n", "Tinggi badan (m)", TinggiBadanMeter);
      System.out.printf("%-20s = %.2f%n", "IMT", IMT);
      
      if (IMT <= 18.5) {
            System.out.print("Termasuk kurus");
        } else if (IMT > 18.5 && IMT <= 24.9) {
            System.out.print("Termasuk normal");
        } else if (IMT >= 25 && IMT <= 29.9) {
            System.out.print("Termasuk gemuk");
        } else {
            System.out.print("Termasuk kegemukan");
        }
      
      }
        
      
    }
    

