import java.util.format;
import java.util.Scanner;
public class ipk {
    public static void main(String[] args) {
        System.out.println("IPK Anda : ");
        System.out.println("Anda mendapatkan : ");
        System.out.println("Biaya pendidikan awal : ");
        System.out.println("Biaya pendidikan akhir : ");

        Scanner input = new Scanner(System.in);
        System.out.print("Masukkan IPK anda : ");
        double nilai = input.nextDouble();
        double jumlah = input.nextDouble();
        double a1 = input.nextDouble();
        System.out.println(" masukkan nilai : ");
        double a2 = input.nextDouble();
        System.out.println(" masukkan nilai : ");
        double b1 = input.nextDouble();
        System.out.println(" masukkan nilai : ");
        double b2 = input.nextDouble();
        System.out.println(" masukkan nilai : ");
        double c1 = input.nextDouble();
        System.out.println(" masuukan nilai : ");
        double c2 = input.nextDouble();
        System.out.println(" masukkan nilai : ");
        double d1 = input.nextDouble();
        System.out.println(" masukkan nilai : ");
        double d2 = input.nextDouble();
        System.out.println(" masukkan nilai : ");
        double e1 = input.nextDouble();
        System.out.println(" masukkan nilai : ");
        double e2 = input.nextDouble();
        System.out.println(" masukkan nilai : ");
        


         



    }
    
}
