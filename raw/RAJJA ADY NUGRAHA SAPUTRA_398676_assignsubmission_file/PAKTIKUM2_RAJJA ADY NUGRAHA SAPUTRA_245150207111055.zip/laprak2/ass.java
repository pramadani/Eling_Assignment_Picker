package LAPRAK;

public class ass {
        public static void main(String[] args) {
            String s = "filkom";
            int val = (s=="filkom")?"Brawijaya": "null";
            System.out.println(s+" "+val);
        }
}
